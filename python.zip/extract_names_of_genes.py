import vcfpy

def extract_gene_symbols(vcf_file, output_file):
    vcf_reader = vcfpy.Reader(open(vcf_file, 'r'))
    gene_symbols = set()

    for record in vcf_reader:
        if 'ANN' in record.INFO:
            annotations = record.INFO['ANN']
            for annotation in annotations:
                details = annotation.split('|')
                gene_symbol = details[3]
                if gene_symbol:
                    gene_symbols.add(gene_symbol)

    with open(output_file, 'w') as f:
        for gene in gene_symbols:
            f.write(f"{gene}\n")

extract_gene_symbols('/Users/a123456/Desktop/ngs/polimorfizmy/freebayes/high_impact_87_fb.vcf', 'FREEBAYES_geneshigh87.txt')
