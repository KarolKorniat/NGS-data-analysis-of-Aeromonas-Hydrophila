import pandas as pd

snps_file1 = pd.read_csv('/Users/a123456/Desktop/ngs/venn_diagram/high/snps_fb87.txt', sep='\t', header=None, names=['CHROM', 'POS'])
snps_file2 = pd.read_csv('/Users/a123456/Desktop/ngs/venn_diagram/high/snps_strelka87.txt', sep='\t', header=None, names=['CHROM', 'POS'])
snps_file3 = pd.read_csv('/Users/a123456/Desktop/ngs/venn_diagram/high/snps_pepe87.txt', sep='\t', header=None, names=['CHROM', 'POS'])

snps_set1 = set(zip(snps_file1['CHROM'], snps_file1['POS']))
snps_set2 = set(zip(snps_file2['CHROM'], snps_file2['POS']))
snps_set3 = set(zip(snps_file3['CHROM'], snps_file3['POS']))

from matplotlib_venn import venn3
import matplotlib.pyplot as plt
plt.figure(figsize=(8, 8))
venn3([snps_set1, snps_set2, snps_set3], ('FreeBayes', 'Strelka', 'Platypus'))
plt.title('Venn Diagram of SNPs Detected in VCF Files')
plt.show()

