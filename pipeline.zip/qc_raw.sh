#!/bin/bash

mkdir QC_przed_trimmingiem
fastqc data/* -o QC_przed_trimmingiem

