#!/bin/bash

mkdir QC_PO_TRIMMINGU
fastqc po_trimmerze/* -o QC_PO_TRIMMINGU

